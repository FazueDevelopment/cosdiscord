rootProject.name = "DiscordSRV" // form settings gradle kts
