![](https://cdn.discordapp.com/attachments/1014563714403410010/1154262490398609439/cos-discord.png "DiscordSRV Logo")

[![](https://discord.com/api/guilds/1087770313347039352/widget.png)](https://discordsrv.com/discord "Discord")
[![](https://img.shields.io/github/release/DiscordSRV/DiscordSRV.svg)](https://github.com/DiscordSRV/DiscordSRV/releases/latest "Latest release")
[![](https://img.shields.io/github/downloads/DiscordSRV/DiscordSRV/total.svg)](https://github.com/DiscordSRV/DiscordSRV/releases/latest "GitHub downloads")
![](https://img.shields.io/github/languages/code-size/DiscordSRV/DiscordSRV.svg "Code size in bytes")
[![](https://img.shields.io/github/contributors/DiscordSRV/DiscordSRV.svg)](https://github.com/DiscordSRV/DiscordSRV/graphs/contributors "GitHub contributors")
[![](https://img.shields.io/github/license/DiscordSRV/DiscordSRV.svg)](https://github.com/DiscordSRV/DiscordSRV/blob/master/LICENSE "License")

A Minecraft to Discord and back link plugin

[![](https://bstats.org/signatures/bukkit/DiscordSRV.svg)](https://bstats.org/plugin/bukkit/DiscordSRV/387 "DiscordSRV on bStats")

## Thanks to:
<table>
    <tr>
        <td align="center" width="50%">
            <a href="https://www.jetbrains.com/idea/"><img src="https://cosdiscord.me/i/x2262.png" alt="Jetbrains IntelliJ IDEA" width="400px"></img></a>
            <p><strong>The Java IDE for Professional Developers by JetBrains</strong></p>            
        </td>
        <td align="center" width="50%">
            <a href="http://www.ej-technologies.com/products/jprofiler/overview.html"><img src="https://www.ej-technologies.com/images/product_banners/jprofiler_large.png" alt="JProfiler" width="150px"></img></a>
            <p><strong>JProfiler's intuitive UI helps you resolve performance bottlenecks, pin down memory leaks and understand threading issues.</strong></p>
        </td>
    </tr>
</table>
